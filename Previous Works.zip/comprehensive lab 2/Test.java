import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Test{
	public static void main(String[] args)throws FileNotFoundException{

		File maze1 = new File("maze1.txt");	
		File maze2 = new File("maze2.txt");	
		File maze3 = new File("maze3.txt");

		Scanner maze1ScanX = new Scanner(maze1); // for the length
		Scanner maze1ScanY = new Scanner(maze1); // for the "height"
		Scanner maze1ScanZ = new Scanner(maze1); // To create the array
		int maze1Length = 0; // The mazes are perfects squares/ not unfilled blobs so it should be fine to get a length.
		int maze1LineNum = 0; 
		String checkMaze1Length = (maze1ScanX.nextLine());
		maze1Length = checkMaze1Length.length();
		//System.out.println(maze1Length);
		while(maze1ScanY.hasNextLine()){
			maze1LineNum++;
			maze1ScanY.nextLine();
		}	
		//System.out.println(maze1LineNum);
		
		/*while(maze1ScanZ.hasNext()){
			System.out.println(maze1ScanZ.nextLine
		} */

		int characterNum = 0;
		char test = 'a';
		char[][] maze1Array = new char [maze1Length][maze1LineNum];
		for(int y = 0; y <  maze1LineNum; y++){
				//System.out.println(y);
			// Read from the file and use character at to set it.
			

				
				
				
			}
		}

	

 } // The end, c'est fini.
