/* Christopher Robert Burk, 80665588 <- The Student/Coder of this assignment

This is a lab to mimic a maze game, and to reach a certain point using user inputs.

/*
  [CS1101] Comprehensive Lab 2
   This work is to be done individually. It is not permitted to.
   share, reproduce, or alter any part of this assignment for any
   purpose. Students are not permitted to share code, upload
   this assignment online in any form, or view/receive/
   modifying code written by anyone else. This assignment is part.
   of an academic course at The University of Texas at El Paso and
   a grade will be assigned for the work produced individually by
   the student.
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main{
public static void main(String[] args)throws FileNotFoundException{

    /*File maze1 = new File("maze1.txt"); 
    File maze2 = new File("maze2.txt"); 
    File maze3 = new File("maze3.txt"); */

    Scanner userinput = new Scanner(System.in);
    System.out.println("Please type which maze you'd like to use EX maze(1-3).txt");
    System.out.println(" It should look like (maze1.txt)");
    File maze = new File(userinput.nextLine());
    int tempMoves = 0;
    int MoveRecord = 0;
    //int[] cordinates = new int [2];

    createSquareMaze(maze);
    loadMaze(maze); //test
    findStartPosition(maze);
    displayMaze(maze, tempMoves);

    userinput.close();
    Scanner movementInput = new Scanner(System.in);
    char moveInput = movementInput.next().charAt(0);



 } // main method

public static char[][] createSquareMaze(File name)throws FileNotFoundException{
Scanner mazeScanX = new Scanner(name);
int mazeLength = 0;
String checkMazeLength = (mazeScanX.nextLine());
mazeLength = checkMazeLength.length();
//System.out.println(mazeLength);
char[][] mazeArray = new char[mazeLength][mazeLength];
return mazeArray;
//int rows = mazeArray.length;
//System.out.println(rows);
}

public static char[][] loadMaze(File name)throws FileNotFoundException{
  Scanner mazeScanY = new Scanner(name);
  char[][] loadMazeArray = createSquareMaze(name);
  int row = 0;
  int linereader = 0;
  while(mazeScanY.hasNextLine()){
    String temp = mazeScanY.nextLine();
    for(int i = 0; i<loadMazeArray.length;i++){
      loadMazeArray[row][i] = temp.charAt(i);
    }
    row++;
    //mazeScanY.nextLine();
  }
  /*for(int g=0;g<loadMazeArray.length;g++){
    for(int j=0;j<loadMazeArray.length;j++){
      System.out.println(loadMazeArray[g][j]); 
    }
  } */
  return loadMazeArray;
}

public static int[] findStartPosition(File name)throws FileNotFoundException{
  char[][] loadMazeArray = loadMaze(name);
  int[] cordinates = new int [2];
  char s = 'S';
  for(int x=0;x<loadMazeArray.length;x++){
    for(int y=0;y<loadMazeArray.length;y++){
      if(loadMazeArray[x][y] == s){      
        cordinates[0] = x;
        cordinates[1] = y;
        //System.out.println(cordinates[0]);
        //System.out.println(cordinates[1]);
      } 
    }
  }
  return cordinates;
}

public static void displayMaze(File name,int tempMoves)throws FileNotFoundException{
  Scanner mazeScanZ = new Scanner(name);
  char[][] loadMazeArray = loadMaze(name);
  if(tempMoves == 0){
    int[] bruh = findStartPosition(name);
    loadMazeArray[(bruh[0])][(bruh[1])] = 'P';
    for(int x=0;x<loadMazeArray.length;x++){
      if(x>=1){
        System.out.println("");
      }
    for(int y=0;y<loadMazeArray.length;y++){
      System.out.print(loadMazeArray[x][y]);
    }
    }
    
  }else{
    for(int x=0;x<loadMazeArray.length;x++){
      if(x>=1){
        System.out.println("");
      }
    for(int y=0;y<loadMazeArray.length;y++){
      System.out.print(loadMazeArray[x][y]);
    }
    }
  } 
} 

public static boolean movePlayer(File name,char movement)throws FileNotFoundException{
  boolean canMove = true;
  char[][] movePlayer = loadMaze(name);

  //if(movement = 'w'){
  // i'd need to check if it'll go out of bounds or if it touches a wall with two different comparisons :)
  }
  for(int l=0;l<movePlayer.length;l++){
    for(int o=0;o<movePlayer.length;o++){
      if(movePlayer[l][o] == '#'){
        canMove = false;
          
    }
  }
  return canMove;
}


} // the end of program

//jhgarcia5@miners.utep.edu the guy to email when I finish.
