import java.util.Scanner;

class Main{
	public static void main(String[] args)throws FileNotFoundException{

		Scanner scanner = new Scanner(System.in); // ze scanna

		System.out.println("Welcome to the Case Switch Calculator");
		System.out.println("Please type a number: ");
			int numOneInput = scanner.nextInt(); // number one(first) input 𓀼 pretty simple? 𓀊
		System.out.println(""); // spacing makes it look nicer when its printed out 𓁔 instead of line after line.
		System.out.println("Now type your second number:");
			int numTwoInput = scanner.nextInt();
		System.out.println("");
		System.out.println("your selected numbers are " +numOneInput+ " and "+numTwoInput); // I like to make sure people know what they typed 𓃕
		System.out.println("");
		System.out.println("Now Enter an operation: Addition [+], Subtraction[-],"); // gotta be specific 𓀥 so people know
		System.out.println("Multiplication [*], and Division[/]");
			char operation = scanner.next().charAt(0);
		System.out.println("");
		System.out.println("You've chose to: "+ operation);
			
			int result = 0;
		switch(operation){
			case'+': result = numOneInput + numTwoInput;
				System.out.println("");
				System.out.println("The result would be: "+ result); //I had to print in here since it breaks after 𓃲
				break;
			case'-': result = numOneInput - numTwoInput;
				System.out.println("");
				System.out.println("The result would be: "+ result);
				break;
			case'*': result = numOneInput*numTwoInput;
				System.out.println("");
				System.out.println("The result would be: "+ result);
				break;
			case'/': result = numOneInput/numTwoInput;
				System.out.println("");
				System.out.println("The result would be: "+ result);
				break; // thanks for looking and have a good one 𓅕
		}
	}
}