class Green {
  public static void main(String[] args) {
    System.out.print("Enter a positive integer for pattern size: ");
    // TODO accept an integer input from the console using Scanner.
int numbah = new Scanner();
System.out.print (numbah + "test");
    // TODO code to generate star pattern below here.
for(int gabagool = 0; gabagool <= numbah; gabagool++){
  for(int inside = 0; inside<=gabagool; inside++){
    if(inside > 0){
      System.out.print("*");
    }
  }
  }
}
}
