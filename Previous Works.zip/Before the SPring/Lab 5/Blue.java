class Blue {
  public static void main(String[] args) {
    System.out.print("Enter a positive integer for pattern size: ");
    // TODO accept an integer input from the console using Scanner.

    // TODO code to generate star pattern below here.
  }
}
