import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Filters {

  public static void main(String[] args)throws IOException {
    // TODO: modify this main method as you wish, to run and test your filter implementations.

    // Read in the image file.
    File f = new File("dog.png");
    BufferedImage img = ImageIO.read(f);

    // For debugging
    System.out.println("Before:");
    System.out.println(Utilities.getRGBArray(0, 0, img)[0]);
    System.out.println(Utilities.getRGBArray(0, 0, img)[1]);
    System.out.println(Utilities.getRGBArray(0, 0, img)[2]);
    // 92 40 27

    // Apply a filter implementation on img.
    /* this is for testing border implementation 𓆋
    int[] borderColor = {235,64,52};
    int borderThickness = 10;
    applyBorder(img, borderThickness, borderColor); */

    applyBlur(img); 

    // For debugging
    System.out.println("After:");
    System.out.println(Utilities.getRGBArray(0, 0, img)[0]);
    System.out.println(Utilities.getRGBArray(0, 0, img)[1]);
    System.out.println(Utilities.getRGBArray(0, 0, img)[2]);
    // 53 53 53

    // Write the result to a new image file.
    f = new File("dog_filtered.png");
    ImageIO.write(img, "png", f);
  }

  public static void applyGrayscale(BufferedImage img) {
    // the approximate formula for grayscaling into HDR should be |y =0.2627R'+0.6780G'+0.0593B'| 𓅠
    // I need to grab the rgb, do the math and then set the rgb to blah blah 𓋅 𓋦
      for(int x = 0; x < img.getWidth();x = x+1){ //column 𓍥
      for(int y = 0; y < img.getHeight();y = y+1){ //row   𓋥
        /* to check the numbers as to why I got an error for out of bounds 𓅀
        System.out.println("x" + x);
        System.out.println("y" + y);
        System.out.println("-----------------");
        System.out.println("width" + img.getWidth());
        System.out.println("height" + img.getHeight());
        System.out.println("-----------------"); */
         int[] tempRGB = Utilities.getRGBArray(y,x,img);
         int greyRGBModifierSum = tempRGB[0] + tempRGB[1] + tempRGB[2];
         int[] greyRGBModifier = {greyRGBModifierSum / 3,greyRGBModifierSum / 3, greyRGBModifierSum / 3};
         Utilities.setRGB(greyRGBModifier,y,x,img); 
        }
      }
    }

  public static void applyNorak(BufferedImage img) {
    // Like Grayscale but with an If loop for >= 459 (153x3) 𓆈

    for(int x = 0; x < img.getWidth();x = x+1){ //column 𓍥
      for(int y = 0; y < img.getHeight();y = y+1){ //row   𓋥
         int[] tempNorakRGB = Utilities.getRGBArray(y,x,img);
         int norakRGBModifierSum = tempNorakRGB[0] + tempNorakRGB[1] + tempNorakRGB[2];
         if(norakRGBModifierSum>=459){
          int[] norakRGBModifier = {norakRGBModifierSum / 3,norakRGBModifierSum / 3, norakRGBModifierSum / 3};
         Utilities.setRGB(norakRGBModifier,y,x,img);
         }
  }
  }
}

  public static void applyBorder(BufferedImage img, int borderThickness, int[] borderColor) {
    // create a range and if its inbetween leave it unchanged otherwise do the bordery 𓅰
  
    for(int x = 0; x < img.getWidth();x = x+1){ //column 𓍥
      for(int y = 0; y < img.getHeight();y = y+1){ //row   𓋥
         int[] borderRGBModifier = borderColor;
         if(x <= borderThickness || x >= img.getWidth()-borderThickness){
         Utilities.setRGB(borderRGBModifier,y,x,img);
         }
         if(y <= borderThickness || y >= img.getHeight()-borderThickness){
         Utilities.setRGB(borderRGBModifier,y,x,img);
         }
  }
  }
  }

  public static void applyMirror(BufferedImage img) {
    // make two x and one y from corner to corner, get their values, and then replace them with one another 𓅲
      for(int y = 0; y < img.getHeight();y = y+1){ //row   𓋥
      for(int x = 0; x < img.getWidth()/2;x = x+1){//column 𓍥
        int reverseX = img.getWidth()-1-x;
        /* to check the values 𓅀
        System.out.println("x" + x);
        System.out.println("y" + y);
        System.out.println("opposite x "+reverseX);
        System.out.println("-----------------");
        System.out.println("width" + img.getWidth());
        System.out.println("height" + img.getHeight()); 
        System.out.println("-----------------"); */

        int[] tempRGB = Utilities.getRGBArray(y,x,img);
        int[] reverseRGB = Utilities.getRGBArray(y,reverseX,img);
         int[] leftRGBArray = {tempRGB[0], tempRGB[1], tempRGB[2]};
         int[] rightRGBArray = {reverseRGB[0],reverseRGB[1],reverseRGB[2]};
         Utilities.setRGB(rightRGBArray,y,x,img);
         Utilities.setRGB(leftRGBArray,y,reverseX,img);
      }
      }
  }
  public static void applyBlur(BufferedImage img) {
    // start at row 1 of each thing, get avg of around pixel 3x3 around, replace with avg, create a seperate array to hold and replace 𓈢 

    //int[][] blurRGBArray = new int[img.getWidth()][img.getHeight()];
    for(int i = 1; i<img.getWidth()-1; i++){
        for(int j = 1; j<img.getHeight()-1; j++){

          Utilities.setRGB(blurApply,j,i,img);

      for(int x = 1; x < img.getWidth()-1;x = x+1){ //column 𓍥
        for(int y = 1; y < img.getHeight()-1;y = y+1){ //row   𓋥
    
        //There's probably a better way but Im gonna just brute force the math
        int[] tempRGBTopLeft = Utilities.getRGBArray(y-1,x-1,img);
        int[] tempRGBTopMiddle = Utilities.getRGBArray(y-1,x,img);
        int[] tempRGBTopRight = Utilities.getRGBArray(y-1,x+1,img);
        int[] tempRGBMiddleLeft = Utilities.getRGBArray(y,x-1,img);
        int[] tempRGBMiddleMiddle = Utilities.getRGBArray(y,x,img);
        int[] tempRGBMiddleRight = Utilities.getRGBArray(y,x+1,img);
        int[] tempRGBBottomLeft = Utilities.getRGBArray(y+1,x-1,img);
        int[] tempRGBBottomMiddle = Utilities.getRGBArray(y+1,x,img);
        int[] tempRGBBottomRight = Utilities.getRGBArray(y+1,x+1,img);

       /* int blurBR = (tempRGBBottomRight[0]+tempRGBBottomRight[1]+tempRGBBottomRight[2])/3;
        int blurBM = (tempRGBBottomMiddle[0]+tempRGBBottomMiddle[1]+tempRGBBottomMiddle[2])/3;
        int blurBL = (tempRGBBottomLeft[0]+tempRGBBottomLeft[1]+tempRGBBottomLeft[2])/3;
        int blurMR = (tempRGBMiddleRight[0]+tempRGBMiddleRight[1]+tempRGBMiddleRight[2])/3;
        int blurMM = (tempRGBMiddleMiddle[0]+tempRGBMiddleMiddle[1]+tempRGBMiddleMiddle[2])/3;
        int blurML = (tempRGBMiddleLeft[0]+tempRGBMiddleLeft[1]+tempRGBMiddleLeft[2])/3;
        int blurTR = (tempRGBTopRight[0]+tempRGBTopRight[1]+tempRGBTopRight[2])/3;
        int blurTL = (tempRGBTopLeft[0]+tempRGBTopLeft[1]+tempRGBTopLeft[2])/3;
        int blurTM = (tempRGBTopMiddle[0]+tempRGBTopMiddle[1]+tempRGBTopMiddle[2])/3;

        int blurModifier = (blurTL+blurTM+blurTR+blurML+blurMM+blurMR+blurBL+blurBM+blurBR)/9;
        */

         blurRed = (tempRGBBottomRight[0]+tempRGBBottomMiddle[0]+tempRGBBottomLeft[0]+tempRGBMiddleRight[0]+tempRGBMiddleMiddle[0]+tempRGBMiddleLeft[0]+
          tempRGBTopRight[0]+tempRGBTopLeft[0]+tempRGBTopMiddle[0])/9;
         blurGreen = (tempRGBBottomRight[1]+tempRGBBottomMiddle[1]+tempRGBBottomLeft[1]+tempRGBMiddleRight[1]+tempRGBMiddleMiddle[1]+tempRGBMiddleLeft[1]+
          tempRGBTopRight[1]+tempRGBTopLeft[1]+tempRGBTopMiddle[1])/9;
         blurBlue = (tempRGBBottomRight[2]+tempRGBBottomMiddle[2]+tempRGBBottomLeft[2]+tempRGBMiddleRight[2]+tempRGBMiddleMiddle[2]+tempRGBMiddleLeft[2]+
          tempRGBTopRight[2]+tempRGBTopLeft[2]+tempRGBTopMiddle[2])/9;
        //int[] blurModifiedArray = {blurRed,blurGreen,blurBlue};
       int blurRGBArrayRed[x][y] = blurRed;
       int blurRGBArrayGreen[x][y] = blurGreen;
       int blurRGBArrayBlue[x][y] = blurBlue;
       int gimmeBlurValueRed = blurRGBArrayRed[x][y];
      int gimmeBlurValueGreen = blurRGBArrayGreen[x][y];
      int gimmeBlurValueBlue = blurRGBArrayBlue[x][y];
      int[] blurApply = {gimmeBlurValueRed,gimmeBlurValueGreen,gimmeBlurValueBlue};
        }
        }    
      }
      }
  }

  public static void applyCustom(BufferedImage img) {
    // I want to create Chromatic-abberation
  }
}
