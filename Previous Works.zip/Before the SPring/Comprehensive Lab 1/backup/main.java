import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;

public class Main{
	public static void main (String[]args) throws FileNotFoundException{
		
			boolean appRunning = true;
				while(appRunning == true){
			Scanner input = new Scanner(System.in);

			System.out.println("Welcome to UtepTube! Please select an option by typing the corresponding number:");
			System.out.println("1. List available videos");
			System.out.println("2. Add a video to the playlist");
			System.out.println("3. View the playlist");
			System.out.println("4. Clear the playlist");
			System.out.println("5. Shutdown UtepTube");
			int choice = input.nextInt();
			int hourQ = 0;
			int minQ = 0;
			int secQ = 0;
			int addedMinutes2 = 0;
			int addedSeconds2 = 0;
	
				{
					File csvList = new File ("corpus.csv");
	try{ 
        		
				Scanner csvReader = new Scanner(csvList);
				csvReader.useDelimiter(",|\\n");

				while(csvReader.hasNext()){
		String videoId = csvReader.next();
		String videoName = csvReader.next();
		String creatorName = csvReader.next();
		String timeMinutes = csvReader.next();
		String timeSeconds = csvReader.next();
		String preRoll = csvReader.next();
		String midRoll = csvReader.next();
		String postRoll = csvReader.next();
		String corpLinerino = ("+-----------+-------------------------------------------------+-------------------+-------+");
			if(choice == 1){
		System.out.println(corpLinerino);
		System.out.println("+"+videoId+"+"+videoName+"+"+creatorName+"+"+timeMinutes+"+"+timeSeconds+"+"+preRoll+"+"+midRoll+"+"
		+postRoll+"+"); // this thing doesn't fit like the og but it works 𓁏
		/* previous iteration if lined format is prefered
		System.out.println(videoId);
		System.out.println(videoName);
		System.out.println(creatorName);
		System.out.println(timeMinutes);
		System.out.println(timeSeconds);
		System.out.println(preRoll);
		System.out.println(midRoll);
		System.out.println(postRoll);
		*/		
			}
			if(choice == 5){
				appRunning = false;
			}


			if(choice == 2){
				try{
					System.out.println("Please input exact video id to add to playlist");
		Scanner videoIdChecker = csvReader;
				videoIdChecker.useDelimiter(",|\\n");

			String id = input.next();
				while(videoIdChecker.hasNext()){
			String videoId2 = csvReader.next();
				if(videoId2.equals(id)){
			String videoName2 = csvReader.next();
			String creatorName2 = csvReader.next();
				System.out.println("Video selected:");
				System.out.println(videoName2);
				System.out.println("by "+ creatorName2);
			String timeMinutes2 = csvReader.next();
				addedMinutes2 = addedMinutes2 + Integer.parseInt(timeMinutes2);
			String timeSeconds2 = csvReader.next();
				addedSeconds2 = addedSeconds2 + Integer.parseInt(timeSeconds2);
						 
			String preRoll2 = csvReader.next();

			String midRoll2 = csvReader.next();
			String postRoll2 = csvReader.next();		
				

				}
				}		
					
		
			}
			catch (NumberFormatException ex){
				System.out.println("invalid");
			}
			
			}
		
			if(choice == 3){
					hourQ = addedMinutes2/60;
				 	secQ = addedSeconds2%60;
				 	minQ = addedMinutes2%60 + addedSeconds2/60;
					System.out.println("total queued play time:"+hourQ+":"+minQ+":"+secQ);
				}

		
				}
			csvReader.close();
			}catch(FileNotFoundException e){
				System.out.println("no corpus.csv");
			}
					
				}	
			}
			


			
			

	
	}
	}