public class Main{
 public static void main(String[] args) {
int [] arr = {1,2,3,4,5,6,7,8}
System.out.println(prodArray(arr,0));
}
	public static int prodArray(int[] arr, int index){
		if(index == arr.length){
			return 1;
		}
		if(arr[index] % 2 == 0){
			return arr [index] * prodArray(arr);
		}
		return prodArray(arr,index+1);
}
}