public class School{

	// Attributes of the school
	private String name;
	private int studentCount;
	private int facultyCount;
	private int tuitionCost;
	private String[3] departmentNames;

	// Constructors
	public School(){
	}
	public School(String nameIn, int tuitionCost){
	}

	// Setters
	
	

}