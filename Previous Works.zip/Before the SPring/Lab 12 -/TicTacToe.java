import java.util.Scanner;

public class TicTacToe {
    private char[][] board;
    private char currentPlayer;
    //Our size will always be set to a 3 by 3 board
    private int boardSize =3;
    public TicTacToe() {
        board = new char[3][3];
        currentPlayer = 'X';
        resetBoard();
    }


    public void resetBoard() {

    }


    public void displayBoard() {

    }

    public boolean makeMove(int row, int col) {

        return false;
    }

    public boolean checkWin() {
        // Check rows

    
        // Check columns

    
        // Check diagonals
    
        // No win found
        return false;
    }    
    public void changePlayer() {
    }

    public boolean isBoardFull() {
        return false;
    }

    public char getCurrentPlayer() {
        return 'X'; ///Please change, x is here as a placeholder
    }
}

