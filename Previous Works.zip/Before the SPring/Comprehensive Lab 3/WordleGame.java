import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class WordleGame {
  
    // the Attributes
  private WordleLetter[][] userGuesses = new WordleLetter[6][5];
  private String answer;
  private int guessNumber = 0;


   // the constructor
  public WordleGame(int puzzleNumber) throws FileNotFoundException{
    answer = WordBank.getAnswerForPuzzleNumber(puzzleNumber); 
 }
  public String getAnswer(){
    return answer;
  }


  public void guess(String guessWord){
    String checkTheGuess = guessWord; 
    WordleLetter first = new WordleLetter(checkTheGuess.charAt(0));
    WordleLetter second = new WordleLetter(checkTheGuess.charAt(1));
    WordleLetter third = new WordleLetter(checkTheGuess.charAt(2));
    WordleLetter fourth = new WordleLetter(checkTheGuess.charAt(3));
    WordleLetter fifth = new WordleLetter(checkTheGuess.charAt(4));

    WordleLetter[] guessArray = {first,second,third,fourth,fifth};
    guessNumber = guessNumber+1;


    for(int i = 0; i< guessArray.length; i++){
      int f = guessNumber-1;
        this.userGuesses[f][i] = guessArray[i];
      if(guessArray[i].getLetter() == answer.charAt(i)){
        guessArray[i].setColor("green");
      }else
        for(int j = 0; j < 5; j++){
           if(guessArray[i].getLetter() == answer.charAt(j)){
            guessArray[i].setColor("yellow");
            break;
          }else{
            guessArray[i].setColor("red");
          }
        }
      /*}*/ 
    }    
    }

  public int getNumberGuessesSoFar(){
    return guessNumber;
  }

  public WordleLetter[] getGuess(int guessNumber){
    WordleLetter[] getGuessTempArray = new WordleLetter[5];
    for(int i = 0; i<getGuessTempArray.length ; i++)
    getGuessTempArray[i] = userGuesses[guessNumber][i];
    return getGuessTempArray;
  }

  public boolean isGameOver(){
      if(isGameWin()){
        return true;
      }else if(guessNumber>=5){
        return true;
      } else{
        return false;
      }
      } 

  public boolean isGameWin(){
      if(userGuesses[guessNumber-1][0].isGreen() &&
         userGuesses[guessNumber-1][1].isGreen() &&
         userGuesses[guessNumber-1][2].isGreen() &&
         userGuesses[guessNumber-1][3].isGreen() &&
         userGuesses[guessNumber-1][4].isGreen()){
        System.out.println("you correctly guessed in: "+ guessNumber+ " guesses.");
        return true;
      }else{
        return false;
      }
  }
  // TODO - include the remainder of the below code back in once rest of class is implemented.
  // Do not modify this method implementation.
  public String toString() {
    // result will be used to build the full answer String
    String result = "";
     // for each word guessed so far
     for (int i = 0; i < getNumberGuessesSoFar(); i++) {
       // get each letter of each word
       for (int j = 0; j < 5; j++) {
         // concatenate it to the result
         // WordleLetter's toString() is automatically invoked here.
         result += getGuess(i)[j];
       }
       // new line separator between each word
       result += "\n";
     }
    return result;
  }
}
