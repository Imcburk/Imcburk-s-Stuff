/* Christopher Robert Burk's Acknowledgement
	[CS 1101] Comprehensive Lab 1
	This work is to be done inidividually. It is not permitted to:
	share, reproduce, or alter any part of this assignment for any purpose.
	Students are not permitted to share code, upload this assignment online, or view/receive/
	modifying code written by anyone else. This assignment is part of an academic course at the University of
	Texas El Paso and a grade will be assigned for the work produced individually by the student */



import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

class CL1_ChrisBurk{
		public static void main(String[] args) throws FileNotFoundException{

			// The file// and reader
			Scanner userScanner = new Scanner(System.in);
			File food = new File("food.txt");

			// The variables
			int choice = 89; // my idea is to create "menus" to choice and use the numbers accordingly.
			int totalItems = 0; // self explanatory name
			double totalCost = 0;
			boolean isRunning = true; // Used later on to "turn off" the program
			boolean delivery = false; // User decides "will switch to true"
			double tipPercent = 0; // Need to divide by 100 after a given number.
			double evilTaxes = 0.0725; // The IRS ;(

				// Printing out the starting menu

				System.out.println("Welcome to UTEP Eats!");
				System.out.println("------Menu------");
				System.out.println(" (1) Add a food ");
				System.out.println(" (2) View cart ");
				System.out.println(" (3) Clear cart ");
				System.out.println(" (4) Checkout ");
				System.out.println(" (5) Exit");
				System.out.println("----------------");

			while(isRunning){
							
				int numbah = userScanner.nextInt(); // This is so you can pick
				//userScanner.nextLine(); // something to do with reading, not really sure...
							//System.out.println(numbah); // checking
							//System.out.println(choice); // testing values
				if((numbah>5)||(numbah<1) ){
								System.out.println("Invalid Choice. Please try again!");
							}
							choice = numbah;
							 //System.out.println(numbah); // checking
							 //System.out.println(choice); // testing values

			switch(numbah){
				case 5:{ System.out.println("Are you sure you want to exit? Type [EXIT]");
					boolean powerOff = false;
					if(userScanner.next().equals("EXIT")){
						System.out.println("");
						System.out.println("Thank you for using Miner Eats. Goodbye!");
						isRunning = powerOff;
					}else{
						System.out.println("Exiting canceled...");
						System.out.println("");
						System.out.println("Welcome to UTEP Eats!");
						System.out.println("------Menu------");
						System.out.println(" (1) Add a food ");
						System.out.println(" (2) View cart ");
						System.out.println(" (3) Clear cart ");
						System.out.println(" (4) Checkout ");
						System.out.println(" (5) Exit");
						System.out.println("----------------");
					} // you can't take something out of a loop so might as well "emulate the option"

				}
					
					break;
				case 1:
					System.out.println("");
					System.out.println("-----=_The__Menu_=------");
					System.out.println("-=Item=-________-=Cost=-");
					Scanner foodScanner = new Scanner(food);
					while(foodScanner.hasNext()){ // start reading food.txt
						System.out.println(foodScanner.nextLine() );
					} // reading off the food.txt
					System.out.println("");// end of adding food
					System.out.println("Please type which food item you'd like to add. use exact casing. [EX:Burger] ");
					System.out.println("");
					Scanner addingScanner = new Scanner(System.in);
					String chosenItem = addingScanner.next();
					//System.out.println(foodItem); debugging lead to me to figure out I needed double, not int
					//addingScanner.nextLine();
					int amountOfFood = 0;
					System.out.println("");
					System.out.println("And how much of that item would you like [EX: 2]");
					System.out.println("");
					amountOfFood = addingScanner.nextInt();
					//addingScanner.nextLine();

					 Scanner menuScanner = new Scanner(food);
            		System.out.println("");
            		System.out.println("You've chosen "+amountOfFood+ " "+chosenItem+"(s).");
            		while(menuScanner.hasNext()){
                	//String tempLine = popScanner.nextLine();
                	String foodItem = menuScanner.next();
                	//System.out.println(foodItem);
                	double foodPrice = menuScanner.nextDouble();
                if(chosenItem.equals(foodItem)){
                	totalItems =  totalItems+(amountOfFood);
					//System.out.println(totalItems);
					totalCost = totalCost + (foodPrice*amountOfFood);
					//System.out.println(totalCost);
                }
            }
/*					if(chosenFood==foodItem){ I should've used .equals but this works now :)
							totalItems =  totalItems+(amountOfFood);
							System.out.println(totalItems)
							totalCost = totalCost + (foodPrice*amountOfFood);
							System.out.println(totalCost);
							break;
						}*/
							System.out.println("");
							System.out.println("Current total items are now: "+totalItems);
							System.out.println("Current total cost is: "+totalCost);
							System.out.println("");
							System.out.println("Welcome to UTEP Eats!");
							System.out.println("------Menu------");
							System.out.println(" (1) Add a food ");
							System.out.println(" (2) View cart ");
							System.out.println(" (3) Clear cart ");
							System.out.println(" (4) Checkout ");
							System.out.println(" (5) Exit");
							System.out.println("----------------");
						break;
				case 3:
					System.out.println("");
					System.out.println("Are you sure you want to clear your cart? Please type [CLEAR] if you wish to.");
					Scanner clearScanner = new Scanner(System.in);
					String clearer = clearScanner.next();
						if(clearer.equals("CLEAR")){
							totalCost = 0;
							totalItems = 0;
							System.out.println("Cart has been cleared. Returning to menu.");
							System.out.println("");
							System.out.println("Welcome to UTEP Eats!");
							System.out.println("------Menu------");
							System.out.println(" (1) Add a food ");
							System.out.println(" (2) View cart ");
							System.out.println(" (3) Clear cart ");
							System.out.println(" (4) Checkout ");
							System.out.println(" (5) Exit");
							System.out.println("----------------");
					}else{
						System.out.println("");
						System.out.println("Cart will not be changed. Returning to menu.");
						System.out.println("");
						System.out.println("Welcome to UTEP Eats!");
						System.out.println("------Menu------");
						System.out.println(" (1) Add a food ");
						System.out.println(" (2) View cart ");
						System.out.println(" (3) Clear cart ");
						System.out.println(" (4) Checkout ");
						System.out.println(" (5) Exit");
						System.out.println("----------------");
					}
					break;
				case 2:
					System.out.println("");
					System.out.println("----------------CART----------------");
					System.out.println("Number of Items: "+ totalItems);
					System.out.println("(Untaxed) Total: "+ totalCost );
					System.out.println("------------------------------------");
					System.out.println("");
					System.out.println("Welcome to UTEP Eats!");
					System.out.println("------Menu------");
					System.out.println(" (1) Add a food ");
					System.out.println(" (2) View cart ");
					System.out.println(" (3) Clear cart ");
					System.out.println(" (4) Checkout ");
					System.out.println(" (5) Exit");
					System.out.println("----------------");
					break;
				case 4:
					System.out.println("");
					System.out.println("Would you like to complete this order as delivery or pickup?[Type: DELIVERY or PICKUP]");
					System.out.println("");
					Scanner checkoutScanner = new Scanner(System.in);
					String grabbing = (checkoutScanner.next());


					if(grabbing.equals("PICKUP")){
						System.out.println("");
						System.out.println("Please come to your designated store for pickup.");
							System.out.println("");
							System.out.println("Your total is: "+(totalCost+(totalCost*evilTaxes)));
							System.out.println("and the number of items is: "+totalItems);
							System.out.println("");
							System.out.println("Thank you for choosing Miner Eats, goodbye!");
							isRunning = false;
					}else if(grabbing.equals("DELIVERY")){
						System.out.println("");
						totalCost = totalCost+5;
						System.out.println("Please enter your address: ");
						System.out.println("");
						checkoutScanner.nextLine(); // helps not give us an error when reading
						String address = (checkoutScanner.next());
						System.out.println("");
						System.out.println("Now Please enter your card crendentials: ");
						System.out.println("");
						checkoutScanner.nextLine();
						String cardPin = checkoutScanner.next();
						if(cardPin.length()==16 ){
							System.out.println("");
							System.out.println("Order Sucessful. Would you like to tip? Please enter tip percent as double digit (EX 18) for 18% or 0% if you'd decline tipping");
							System.out.println("");
							tipPercent = (checkoutScanner.nextInt()/100);
							System.out.println("");
							System.out.println("Your total is: "+ (totalCost+((totalCost*evilTaxes)+totalCost*tipPercent)));
							System.out.println("and the number of items is: "+totalItems);
							System.out.println("");
							System.out.println("Thank you for choosing Miner Eats, goodbye!");
							isRunning = false;
						}else{
							System.out.println("");
							System.out.println("Invalid crendentials. Returning to menu.");
							System.out.println("");
							System.out.println("Welcome to UTEP Eats!");
							System.out.println("------Menu------");
							System.out.println(" (1) Add a food ");
							System.out.println(" (2) View cart ");
							System.out.println(" (3) Clear cart ");
							System.out.println(" (4) Checkout ");
							System.out.println(" (5) Exit");
							System.out.println("----------------");
						}
					}else{
						System.out.println("Action not specified. Returning to menu.");
						System.out.println("");
						System.out.println("Welcome to UTEP Eats!");
						System.out.println("------Menu------");
						System.out.println(" (1) Add a food ");
						System.out.println(" (2) View cart ");
						System.out.println(" (3) Clear cart ");
						System.out.println(" (4) Checkout ");
						System.out.println(" (5) Exit");
						System.out.println("----------------");
						}
					break;
				
			}



			} // end of program

			/* THIS IS THE CODING GRAVEYARD  */

			/*else{
				//System.out.println(numbah); // testing values
								choice = numbah;
							} // End of the picking function */

			/* if(!isRunning){
				System.out.println("");
				System.out.println("Thank you for using Miner Eats. Goodbye!");
			} obsolete code, in an attempt to create a "power" feature */

			/*if(choice == 0){ trying to see if this works
					System.out.println("Welcome to UTEP Eats!");
					System.out.println("------Menu------");
					System.out.println(" (1) Add a food ");
					System.out.println(" (2) View cart ");
					System.out.println(" (3) Clear cart ");
					System.out.println(" (4) Checkout ");
					System.out.println(" (5) Exit");
					System.out.println("----------------");
					choice = 89; // so it doesn't keep printing
				} /* This is the starting UI  */

			/*String splitMenu = foodScanner.nextLine(); 
						int i; // This is something I've read on how to seperate the "string"
						for(i = 0; i< (foodScanner.next() ).length(); i++){ 
						//Source :https://stackoverflow.com/questions/16787099/how-to-split-the-string-into-string-and-integer-in-java
							char spaceAdder = foodScanner.next().charAt(i);
							if(spaceAdder == ' ');
							break;
						}
						String firstMenu = splitMenu.substring(0,i);
						String secondMenu = splitMenu.substring(i);
						System.out.println(firstMenu+"  "+secondMenu); */ 

			/*if(choice == 5){/* "The exit option" */
					/*System.out.println("Are you sure you want to exit? Type [EXIT]");
				}boolean powerOff = false;
					if(userScanner.next().equals("EXIT")){
						System.out.println("");
						System.out.println("Thank you for using Miner Eats. Goodbye!");
						isRunning = powerOff;
					}else{
						System.out.println("Exiting canceled..."); 
					} // you can't take something out of a loop so might as well "emulate the option" */

			/* if(choice == 1){ // The order food option
					System.out.println("");
					System.out.println("-----=_The__Menu_=------");
					System.out.println("-=Item=-________-=Cost=-");
					while(foodScanner.hasNextLine()){ // start reading food.txt
						System.out.println(foodScanner.next() );
					} // reading off the food.txt
				System.out.println("");
				} // end of adding food */

			/*if(choice == 5){
				System.out.println("Check!");
			}*/

			// case '5' compared to case 5 is a big difference :)

			/*if(grabbing == "DELIVERY"){
						totalCost = totalCost+5;
						System.out.println("Please enter you address: ");
						String address = (checkoutScanner.next());
						System.out.println("Now Please enter you card crendentials: ");
						String cardPin = checkoutScanner.next();
						if(cardPin.length()==16 ){
							System.out.println("Order Sucessful. Would you like to tip? Please enter tip percent as double digit (EX 18) for 18% or 0% if you'd decline tipping");
							tipPercent = checkoutScanner.nextInt();
							System.out.println("");
							totalCost = totalCost+ (evilTaxes*totalCost);
							totalCost = totalCost+ (totalCost*tipPercent);
							System.out.println("Your total is: "+ (totalCost));
							System.out.println("and the number of items is: "+totalItems);
							isRunning = false;
						}else {
							System.out.println("Please try again!"); 
						} */

						
					/*if(userScanner.next() =="CLEAR"){
						totalItems = 0;
						totalCost = 0;
					}else{
						System.out.println("Cart will not be changed. Returning to menu.");
						System.out.println("");
						System.out.println("Welcome to UTEP Eats!");
						System.out.println("------Menu------");
						System.out.println(" (1) Add a food ");
						System.out.println(" (2) View cart ");
						System.out.println(" (3) Clear cart ");
						System.out.println(" (4) Checkout ");
						System.out.println(" (5) Exit");
						System.out.println("----------------");
					}
					break; */

				/*	if(chosenFood == foodItem){
							totalItems =  totalItems+(amountOfFood);
							totalCo
							st = totalCost + (foodPrice*amountOfFood);
							System.out.println("");
							System.out.println("Current total items are now: "+totalItems);
							System.out.println("Current total cost is: "+totalCost);
							System.out.println("");
							System.out.println("Welcome to UTEP Eats!");
							System.out.println("------Menu------");
							System.out.println(" (1) Add a food ");
							System.out.println(" (2) View cart ");
							System.out.println(" (3) Clear cart ");
							System.out.println(" (4) Checkout ");
							System.out.println(" (5) Exit");
							System.out.println("----------------");
							*/
					/*}
					if(chosenFood == foodItem){
							totalItems =  totalItems+(amountOfFood);
							totalCost = totalCost + (foodPrice*amountOfFood);
							System.out.println("");
							System.out.println("Current total items are now: "+totalItems);
							System.out.println("Current total cost is: "+totalCost);
							System.out.println("");
							System.out.println("Welcome to UTEP Eats!");
							System.out.println("------Menu------");
							System.out.println(" (1) Add a food ");
							System.out.println(" (2) View cart ");
							System.out.println(" (3) Clear cart ");
							System.out.println(" (4) Checkout ");
							System.out.println(" (5) Exit");
							System.out.println("----------------");

					}*/

					/*switch(clearer) {
						case "CLEAR":
							totalCost = 0;
							totalItems = 0;
							System.out.println("Cart has been cleared. Returning to menu.");
							System.out.println("");
							System.out.println("Welcome to UTEP Eats!");
							System.out.println("------Menu------");
							System.out.println(" (1) Add a food ");
							System.out.println(" (2) View cart ");
							System.out.println(" (3) Clear cart ");
							System.out.println(" (4) Checkout ");
							System.out.println(" (5) Exit");
							System.out.println("----------------");
							break;
						default:
							System.out.println("Cart will not be changed. Returning to menu.");
							System.out.println("");
							System.out.println("Welcome to UTEP Eats!");
							System.out.println("------Menu------");
							System.out.println(" (1) Add a food ");
							System.out.println(" (2) View cart ");
							System.out.println(" (3) Clear cart ");
							System.out.println(" (4) Checkout ");
							System.out.println(" (5) Exit");
							System.out.println("----------------");
							break;
							} */

						/*	switch(grabbing){
						case "DELIVERY":
							totalCost = totalCost+5;
						System.out.println("Please enter you address: ");
						checkoutScanner.nextLine(); // helps not give us an error when reading
						String address = (checkoutScanner.next());
						System.out.println("Now Please enter you card crendentials: ");
						checkoutScanner.nextLine();
						String cardPin = checkoutScanner.next();
						if(cardPin.length()==16 ){
							System.out.println("Order Sucessful. Would you like to tip? Please enter tip percent as double digit (EX 18) for 18% or 0% if you'd decline tipping");
							tipPercent = (checkoutScanner.nextInt()/100);
							System.out.println("");
							System.out.println("Your total is: "+ (totalCost+((totalCost*evilTaxes)+totalCost*tipPercent)));
							System.out.println("and the number of items is: "+totalItems);
							System.out.println("");
							System.out.println("Thank you for choosing Miner Eats, goodbye!");
							isRunning = false;
						}else{
							System.out.println("Please try again!");
						}
						break;
						case "PICKUP":
							System.out.println("Please come to your designated store for pickup.");
							System.out.println("");
							System.out.println("Your total is: "+(totalCost+(totalCost*evilTaxes)));
							System.out.println("and the number of items is: "+totalItems);
							System.out.println("");
							System.out.println("Thank you for choosing Miner Eats, goodbye!");
							isRunning = false;
						default:
							System.out.println("Action not specified. Returning to menu.");
							System.out.println("");
							System.out.println("Welcome to UTEP Eats!");
							System.out.println("------Menu------");
							System.out.println(" (1) Add a food ");
							System.out.println(" (2) View cart ");
							System.out.println(" (3) Clear cart ");
							System.out.println(" (4) Checkout ");
							System.out.println(" (5) Exit");
							System.out.println("----------------");
							break;  A lot of trial and error but here we are...*/

	}
}