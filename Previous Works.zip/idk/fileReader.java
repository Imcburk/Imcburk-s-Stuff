import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class fileReader{
	public static void main(String[] args) throws FileNotFoundException{

		File myFile = new File("Practice.txt");
		int counter = 0;

		scanner.useDelimiter(",");

		while(scanner.hasNextLine()){
			counter ++;
			System.out.println(scanner.nextLine());
		}
		System.out.println(counter);
		System.out.println("You have reached the end! ");
	}
}