class Main{
	public static void main(String[] args){
		/*String myName = "Christopher Robert Burk";
		System.out.println("Hello! my name is: "+ myName + "and I hope you're day is alright atleast.");
		System.out.println("And this isn't my first rodeo."); */
		String[] nameList = {"Isa","Max","Andrea"};

		for(int i=0; i<nameList.length; i++){
			System.out.println("Hello "+ nameList[i] + ", I hope you've been well.");
		}
		/*System.out.println("Hello "+name[0]);
		System.out.println("Hello "+name[1]);
		System.out.println("Hello "+name[2]);*/

	}
}