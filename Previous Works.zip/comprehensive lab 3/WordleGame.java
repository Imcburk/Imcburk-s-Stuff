import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class WordleGame {
  /* allGuesses represents the wordle game */
  private WordleLetter[][] allGuesses = new WordleLetter[6][5];
  private String puzzleAnswer;
  private int guessNumber = 0;

  public WordleGame(int puzzleNumber) throws FileNotFoundException{
    puzzleAnswer = WordBank.getAnswerForPuzzleNumber(puzzleNumber); 
 }
  public String getAnswer(){
    return puzzleAnswer;
  }

  public void guess(String guessWord){
    String checkTheGuess = guessWord; 
    
    
    WordleLetter first = new WordleLetter(checkTheGuess.charAt(0));
    WordleLetter second = new WordleLetter(checkTheGuess.charAt(1));
    WordleLetter third = new WordleLetter(checkTheGuess.charAt(2));
    WordleLetter fourth = new WordleLetter(checkTheGuess.charAt(3));
    WordleLetter fifth = new WordleLetter(checkTheGuess.charAt(4));

    WordleLetter[] guessArray = {first,second,third,fourth,fifth};
    guessNumber = guessNumber++;
    int f = 0;

    for(int i = 0; i< guessArray.length; i++){
      //int f = guessNumber;
        this.allGuesses[f][i] = guessArray[i];
        f++ ;
      if(guessArray[i].getLetter() == puzzleAnswer.charAt(i)){
        guessArray[i].setColor("green");
        //System.out.println(guessArray[i].isGreen());
      }else
        for(int j = 0; j < 5; j++){
           if(guessArray[i].getLetter() == puzzleAnswer.charAt(j)){
            guessArray[i].setColor("yellow");
            break;
          }else{
            guessArray[i].setColor("red");
          }
        }
      
    }
    }

  public int getNumberGuessesSoFar(){
    return guessNumber;
  }

  public WordleLetter[] getGuess(int guessNumber){
    WordleLetter[] getGuessTempArray = new WordleLetter[5];
    for(int i = 0; i<getGuessTempArray.length ; i++)
    getGuessTempArray[i] = allGuesses[guessNumber][i];
    return getGuessTempArray;
  }

  public boolean isGameOver(){
    for(int i = 0; i<5 ; i++){
      if(allGuesses[i][0].isGreen() &&
         allGuesses[i][1].isGreen() &&
         allGuesses[i][2].isGreen() &&
         allGuesses[i][3].isGreen() &&
         allGuesses[i][4].isGreen()){
        return true;
      } else if(guessNumber == 5){
        return true;
      } else{
        return false;
      }
  } throw new RuntimeException("This should work"); // because compiling magic
  } 

  public boolean isGameWin(){
    System.out.println("the guess number is "+ guessNumber);
      if(allGuesses[guessNumber][0].isGreen() &&
         allGuesses[guessNumber][1].isGreen() &&
         allGuesses[guessNumber][2].isGreen() &&
         allGuesses[guessNumber][3].isGreen() &&
         allGuesses[guessNumber][4].isGreen()){
        return true;
      }else{
        return false;
      }
  }


  /*------TODO - implement according to spec ------*/
  

  /*------- TODO - include the remainder of the below code back in once rest of class is implemented.
            Do not modify this method implementation ------*/

  public String toString() {
    /* result will be used to build the full answer String */ 
    String result = ""; 
       /* for each word guessed so far */ 
     for (int i = 0; i < getNumberGuessesSoFar(); i++) {
         /* get each letter of each word */
       for (int j = 0; j < 5; j++) {
           /* concatenate it to the result */ 
           /* WordleLetter's toString() is automatically invoked here. */
         result += getGuess(i)[j];
       }
         /* new line separator between each word */ 
       result += "\n";
     }
    return result;
  }
}
