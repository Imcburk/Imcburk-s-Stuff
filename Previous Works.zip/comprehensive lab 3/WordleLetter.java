public class WordleLetter {
	private char letter;
	private String color = "";

// THE CONSTRUCTOR FOR CHRIST SAKE
	public WordleLetter(char letterIn){
		this.letter = letterIn;
	}

// THE SETTAH and GETTAH?

	public char getLetter(){
		return this.letter;
	}

	public boolean isColorSet(char letterIn){
		if(!color.equals(null)){
			return true;
		}else{
			return false;
		}
	}

	public boolean isGreen(){
		if(color.equals("green")){
			return true;
		} else{
			return false;
		}
	} 

	public void setColor(String colorIn){
		//apparently there needs to be a green,yellow,red
		if(colorIn.equals("green")){
			this.color = colorIn;
		 } else if(colorIn.equals("yellow")) {
			this.color = colorIn;
		 } else if(colorIn.equals("red")) {
			this.color = colorIn;
		 } else{
			System.out.println("How?");
		 }	


	}

	/*  -----------------------------------------------------------------------
		TODO - include the below code back in once rest of class is implemented. 
		Do not modify this method implementation. 
		-----------------------------------------------------------------------*/ 
	public String toString() {
		/*	Determine the special characters to add at the beginning of the String
			to change the text color to the right color. */
		String colorCode;
		if(color.equals("green")) {
			colorCode = "\u001B[32m";
		} else if(color.equals("yellow")) {
			colorCode = "\u001B[33m";
		} else {
			colorCode = "\u001B[31m";
		}
	
		/*	These are the special character to add 
			to the end of the String 
			to signify the end of the color change. */
		String resetCode = "\u001B[0m";

		/*  Surround the letter with space characters and with 
			the above color changing special characters. */ 
		return String.format(
			"%s %s %s",
			colorCode, letter, resetCode);
	}
}
