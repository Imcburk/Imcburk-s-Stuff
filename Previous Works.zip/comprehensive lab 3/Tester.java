import java.io.FileNotFoundException;

/**
 * Tester file.
 *
 * Use this main method to test classes and methods as you create them.
 * Feel free to modify this file as you wish.
 */
public class Tester {
  public static void main(String[] args) throws FileNotFoundException {
    System.out.println("Test for WordBank");
    System.out.println(WordBank.checkInDictionary("hello"));  // true
    System.out.println(WordBank.checkInDictionary("asdfg"));  // false
    System.out.println(WordBank.checkInDictionary("aalii")); // ZASED!!?!?!?
    System.out.println(WordBank.checkInDictionary("aahed")); //WE'RE LOSING THEY/IT/THEMOTHY??!?

    System.out.println(WordBank.getAnswerForPuzzleNumber(0)); // bused
    System.out.println(WordBank.getAnswerForPuzzleNumber(0)); // bused
    System.out.println(WordBank.getAnswerForPuzzleNumber(1)); // plumb
    
    System.out.println("");
    System.out.println("Test for WordleLetter.java");
    char bruh = 'l';
    WordleLetter test = new WordleLetter('l');
    // null pointer exception >>> System.out.println(test.isColorSet());
    test.setColor("green");
    //System.out.println(test.isColorSet());
    System.out.println(test.isGreen());
    // TODO add tests for Wordle Game
    System.out.println("");
    System.out.println("Test for WordleGame.java");
    WordleGame testificate = new WordleGame(0);
    System.out.println(testificate.getAnswer());
    testificate.guess("buses");
    for(int i = 0; i<5; i++){
      System.out.println(testificate.getGuess(0)[i]);
      System.out.println(testificate.getAnswer().charAt(i));
    }
    }
    


    // TODO add tests for Main

  }
